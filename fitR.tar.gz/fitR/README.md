fitR
====

Functions for model fitting and inference

## Installation
The easiest way to install `fitR` is to use the `devtools` package:

```r
# install.packages("devtools")
library(devtools)
install_github("sbfnk/fitR")
```
